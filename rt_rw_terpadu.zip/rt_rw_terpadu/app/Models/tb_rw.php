<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tb_rw extends Model
{
    protected $table = 'tb_rw';
    protected $fillable = [
        'Nama_Rw','Masa_Jabatan','No_Telp','Email',
    ];
    protected $primaryKey = 'id';
    use HasFactory;
}
